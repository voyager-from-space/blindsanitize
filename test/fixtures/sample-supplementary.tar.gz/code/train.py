__author__ = "Ada Example"
import os
DATA = "/home/ada/data"
# contact: ada@acme-lab.example
print("training")
